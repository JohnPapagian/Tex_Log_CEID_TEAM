
package hotail;


public class Sensor_Touch extends Sensors{
    
        private float weight;

    Sensor_Touch(float lat,float lon,float w) {
        super(lat,lon);
        weight=w;
        
            
  }
    
    
}
