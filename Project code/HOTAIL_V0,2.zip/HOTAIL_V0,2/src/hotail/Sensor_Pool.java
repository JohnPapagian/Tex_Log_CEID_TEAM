
package hotail;


public class Sensor_Pool extends Sensors{
    private float pool_temp;

    Sensor_Pool(float lat,float lon,float temp) {
        super(lat,lon);
        pool_temp=temp;
        
            
  }



}
