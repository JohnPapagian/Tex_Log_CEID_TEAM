
package hotail;

public class Sensor_Temperature extends Sensors{
    
        private float temp;

    Sensor_Temperature(float lat,float lon,float tmp) {
        super(lat,lon);
        temp=tmp;
        
            
  }
    
    
    
    
}
