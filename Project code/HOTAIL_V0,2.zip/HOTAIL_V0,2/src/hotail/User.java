
package hotail;


public class User {
    
    private String username;
    private String password; 
    
    
    
    User(String name,String pass) {
        username = name;
        password = pass;
  }
    
    
}
