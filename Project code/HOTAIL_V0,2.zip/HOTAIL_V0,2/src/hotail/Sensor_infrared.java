
package hotail;


public class Sensor_infrared extends Sensors{
    
    
        private boolean occupied;

    Sensor_infrared(float lat,float lon,boolean occ) {
        super(lat,lon);
        occupied=occ;
        
            
  }
    
    
    
    
}
