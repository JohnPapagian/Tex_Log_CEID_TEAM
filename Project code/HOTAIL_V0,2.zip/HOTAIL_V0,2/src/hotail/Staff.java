
package hotail;


public class Staff {
          
    
    
    private static  int salary;

    public static int get_salary()
    {
        return salary;
    }
}
