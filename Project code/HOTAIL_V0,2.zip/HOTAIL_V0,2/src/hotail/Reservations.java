
package hotail;


public class Reservations {
    
    private int reservation_code;
        
        
       Reservations(int code) {
        this.reservation_code=code;
        
            
  }
    
    
    public int get_reservation_code()
            {
                return reservation_code;
        
            }
}
